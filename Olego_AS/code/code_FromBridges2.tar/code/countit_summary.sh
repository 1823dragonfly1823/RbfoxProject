#/bin/bash
while read -r sample
do
	echo $sample
	sbatch ./code/countit_summary.job $sample

	echo ${sample}_submitted
done
