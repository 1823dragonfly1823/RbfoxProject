#!/bin/bash
while read -r sample
do
	echo $sample
	sbatch ./code/gapless.job $sample

	echo ${sample}_submitted
done
